// src/app/core/models/game.interfaces.ts

export interface NpcData {
  tipo: 'guia' | 'agente' | 'neutro';
  fe: number;
  dialogos: any;
}

export interface Buff {
  tipo: 'aumento_temporario_fe' | 'protecao_agente';
  valor?: number;
  turnos_restantes: number;
}

export interface GameState {
  fase_atual: number;
  heroi_fe_percent: number;
  pistas: string[];
  personagens_atuais: { [key: string]: NpcData };
  all_characters_in_game_pool: { [key: string]: NpcData };
  game_over: boolean;
  dialogo_atual: { npc: string, opcoes: any[] } | null;
  nome_jogador_global: string;
  heroi_inventory: string[];
  activeBuffs: Buff[]; // Novo
}

export interface LogLine {
  text: string;
  className: string;
}
