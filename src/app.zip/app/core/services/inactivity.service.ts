// src/app/core/services/inactivity.service.ts

import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { GameStateService } from './game-state.service';

@Injectable({
  providedIn: 'root'
})
export class InactivityService {
  private _isScreensaverActive = new BehaviorSubject<boolean>(false);
  public isScreensaverActive$ = this._isScreensaverActive.asObservable();

  private inactivityTimer: any;

  constructor(private gameStateSvc: GameStateService) { }

  public resetInactivityTimer() {
    const config = this.gameStateSvc.gameData.config?.screensaver;

    if (!config || !config.enabled) {
      return;
    }

    clearTimeout(this.inactivityTimer);
    if (this._isScreensaverActive.getValue()) {
      this._isScreensaverActive.next(false);
    }

    this.inactivityTimer = setTimeout(() => {
      this.forceScreensaver(); // O temporizador agora também força a ativação
    }, config.timeout_seconds * 1000);
  }

  /**
   * Ativa a proteção de tela imediatamente.
   * Usado tanto pelo temporizador quanto pelo comando de teste.
   */
  public forceScreensaver() {
    this._isScreensaverActive.next(true);
    this.stopTimer(); // Para o temporizador para que não se reative sozinho
  }

  public stopTimer() {
    clearTimeout(this.inactivityTimer);
  }
}
