// src/app/core/services/command.service.ts

import { Injectable } from '@angular/core';
import { GameStateService } from './game-state.service';
import { InactivityService } from './inactivity.service';

@Injectable({
  providedIn: 'root'
})
export class CommandService {

  constructor(
    private gameStateSvc: GameStateService,
    private inactivitySvc: InactivityService
  ) { }

  processCommand(command: string) {
    const gameState = this.gameStateSvc.gameState;
    if (gameState.game_over) return;

    // Comando oculto verificado primeiro
    if (command == 'screensaver.exe') {
      this.inactivitySvc.forceScreensaver();
      return; // Interrompe para não aparecer no log
    }

    this.gameStateSvc.addLog(`> ${command}`, 'log-heroi');
    const [acao, ...args] = command.split(' ');
    const argumento = args.join(' ');

    if (gameState.dialogo_atual && acao !== 'responder') {
      this.gameStateSvc.addLog("Use 'responder [num]' para continuar a conversa.", 'log-sistema');
      return;
    }

    const comandos: { [key: string]: Function } = {
      "novo": () => this.gameStateSvc.startNewGame(),
      "ajuda": () => this.gameStateSvc.addLog("Comandos: falar, usar, online, pistas, inventario, salvar, carregar, continuar, novo, sair", 'log-positivo'),
      "online": () => this.listarPersonagensOnline(),
      "pistas": () => this.listarPistas(),
      "inventario": () => this.listarInventario(),
      "falar": () => this.iniciarDialogo(argumento),
      "responder": () => this.processarRespostaDialogo(command),
      "salvar": () => this.gameStateSvc.exportSaveToFile(),
      "carregar": () => this.gameStateSvc.requestFileUpload(),
      "continuar": () => this.gameStateSvc.loadFromAutosave(),
      "usar": () => this.usarItem(argumento),
      "sair": () => this.gameStateSvc.showInitialScreen()
    };

    if (comandos[acao]) {
      comandos[acao]();
    } else {
      this.gameStateSvc.addLog(`Comando não reconhecido: ${acao}`, 'log-negativo');
    }

    if (!gameState.dialogo_atual) {
        this.gameStateSvc.decrementarBuffs();
    }
  }
  
  private usarItem(itemName: string) {
    if (!itemName) {
      this.gameStateSvc.addLog("Especifique um item para usar. Ex: usar oracao", 'log-negativo');
      return;
    }
    
    const gameState = this.gameStateSvc.gameState;
    const gameData = this.gameStateSvc.gameData;

    const itemKey = Object.keys(gameData.itens).find(key => 
      gameData.itens[key].nome.toLowerCase() === itemName.toLowerCase()
    );

    if (itemKey && gameState.heroi_inventory.includes(itemKey)) {
      this.gameStateSvc.aplicarEfeitoItem(itemKey);
    } else {
      this.gameStateSvc.addLog(`Você não possui o item '${itemName}'.`, 'log-negativo');
    }
  }

  // ... (outras funções como listarPersonagensOnline, etc. permanecem iguais)
  private listarPersonagensOnline() {
    const gameState = this.gameStateSvc.gameState;
    this.gameStateSvc.addLog("Personagens online:", 'log-sistema');
    Object.entries(gameState.personagens_atuais).forEach(([name, data]) => {
      const feStr = `(Fé: ${data.fe.toFixed(0)}%)`;
      this.gameStateSvc.addLog(`- ${name.toUpperCase()} ${feStr}`, this.gameStateSvc.getNpcColor(data));
    });
  }

  private listarPistas() {
    const gameState = this.gameStateSvc.gameState;
    this.gameStateSvc.addLog("Pistas coletadas:", 'log-sistema');
    if (gameState.pistas.length === 0) {
        this.gameStateSvc.addLog("Nenhuma.", 'log-sistema');
        return;
    }
    gameState.pistas.forEach(pista => this.gameStateSvc.addLog(`- ${pista}`, 'log-positivo'));
  }
  
  private listarInventario() {
    const gameState = this.gameStateSvc.gameState;
    const gameData = this.gameStateSvc.gameData;
    this.gameStateSvc.addLog("Inventário:", 'log-sistema');
    if (gameState.heroi_inventory.length === 0) {
        this.gameStateSvc.addLog("Vazio.", 'log-sistema');
        return;
    }
    gameState.heroi_inventory.forEach(itemKey => {
        const item = gameData.itens[itemKey];
        if(item) {
            this.gameStateSvc.addLog(`- ${item.nome}: ${item.descricao}`, 'log-positivo');
        }
    });
  }

  private iniciarDialogo(npcName: string) {
    const gameState = this.gameStateSvc.gameState;
    if (gameState.personagens_atuais[npcName]) {
      this.setDialogoAtual(npcName, 'inicial');
    } else {
      this.gameStateSvc.addLog("[SISTEMA]: Personagem não encontrado.", 'log-negativo');
    }
  }

  private setDialogoAtual(npcName: string, dialogoKey: string) {
    const gameState = this.gameStateSvc.gameState;
    const npcData = gameState.personagens_atuais[npcName];
    const dialogo = npcData.dialogos[dialogoKey];
    this.gameStateSvc.addLog(`[${npcName.toUpperCase()}]: ${dialogo.texto}`, this.gameStateSvc.getNpcColor(npcData));

    if (dialogo.opcoes && dialogo.opcoes.length > 0) {
      this.gameStateSvc.setGameState({ dialogo_atual: { npc: npcName, opcoes: dialogo.opcoes } });
      dialogo.opcoes.forEach((opt: any, i: number) => {
        if (opt.requer_pista && !gameState.pistas.includes(opt.requer_pista)) {
          this.gameStateSvc.addLog(`  ${i + 1}. [Pista Necessária]`, 'log-sistema');
        } else {
          this.gameStateSvc.addLog(`  ${i + 1}. ${opt.texto}`, 'log-heroi');
        }
      });
    } else {
      this.gameStateSvc.setGameState({ dialogo_atual: null });
    }
  }

  private processarRespostaDialogo(command: string) {
    const gameState = this.gameStateSvc.gameState;
    if (!gameState.dialogo_atual) return;

    const { npc: npcName, opcoes } = gameState.dialogo_atual;
    const numResposta = parseInt(command.split(' ')[1], 10) - 1;

    if (isNaN(numResposta) || numResposta < 0 || numResposta >= opcoes.length) {
      this.gameStateSvc.addLog("[SISTEMA]: Resposta inválida.", 'log-negativo');
      return;
    }
    const opcao = opcoes[numResposta];
    
    if (opcao.requer_pista && !gameState.pistas.includes(opcao.requer_pista)) {
        this.gameStateSvc.addLog("[SISTEMA]: Você não tem a pista necessária.", 'log-negativo');
        return;
    }

    this.gameStateSvc.addLog(`> ${opcao.texto}`, 'log-heroi');

    const npcState = gameState.personagens_atuais[npcName];
    this.gameStateSvc.processarInteracaoFe(npcState, npcName, opcao.efeito_fe_npc);

    if (opcao.adicionar_pista && !gameState.pistas.includes(opcao.adicionar_pista)) {
        this.gameStateSvc.addPista(opcao.adicionar_pista);
    }
    
    if (opcao.proximo_dialogo && npcState.dialogos[opcao.proximo_dialogo]) {
        this.setDialogoAtual(npcName, opcao.proximo_dialogo);
    } else {
        this.gameStateSvc.setGameState({ dialogo_atual: null });
    }

    this.gameStateSvc.decrementarBuffs();
  }
}
