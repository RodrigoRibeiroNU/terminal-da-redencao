// src/app/core/services/game-state.service.ts

import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { GameState, NpcData, LogLine, Buff } from '../models/game.interfaces';
import packageInfo from '../../../../package.json';

@Injectable({
  providedIn: 'root'
})
export class GameStateService {
  private readonly initialGameState: GameState = {
    fase_atual: 1,
    heroi_fe_percent: 70,
    pistas: [],
    personagens_atuais: {},
    all_characters_in_game_pool: {},
    game_over: false,
    dialogo_atual: null,
    nome_jogador_global: "",
    heroi_inventory: [],
    activeBuffs: []
  };

  private readonly _gameState = new BehaviorSubject<GameState>(this.getInitialGameState());
  readonly gameState$ = this._gameState.asObservable();

  private readonly _terminalLog = new BehaviorSubject<LogLine[]>([]);
  readonly terminalLog$ = this._terminalLog.asObservable();

  private fileUploadRequest = new Subject<void>();
  readonly fileUploadRequest$ = this.fileUploadRequest.asObservable();

  gameData: any = {};
  
  constructor() { }

  get gameState(): GameState {
    return this._gameState.getValue();
  }

  setGameState(newState: Partial<GameState>) {
    this._gameState.next({ ...this.gameState, ...newState });
    this.autosaveToLocalStorage();
  }

  addLog(text: string, className: string = '') {
    const currentLog = this._terminalLog.getValue();
    this._terminalLog.next([...currentLog, { text, className }]);
  }
  
  clearLog() {
    this._terminalLog.next([]);
  }

  showInitialScreen() {
    this.setGameState(this.getInitialGameState());
    this.clearLog();
    this.addLog(`Terminal da Redenção v${packageInfo.version}`, 'log-sistema');
    this.addLog("Digite 'novo' para iniciar, 'carregar' para enviar um ficheiro, ou 'continuar' para usar o último autosave.", 'log-sistema');
  }

  startNewGame() {
    this.setGameState({ ...this.getInitialGameState(), nome_jogador_global: 'PENDING' });
    this.clearLog();
    this.addLog("Iniciando novo jogo... Por favor, insira o seu nome:", 'log-sistema');
  }
  
  setPlayerName(name: string) {
    const saudacao = this.gameData.personagens_base.gabriel.dialogos.saudacao.replace('{jogador_nome}', name.toUpperCase());
    
    const allChars: { [key: string]: NpcData } = {};
    Object.keys(this.gameData.personagens_base).forEach(nome => {
        allChars[nome] = JSON.parse(JSON.stringify(this.gameData.personagens_base[nome]));
    });

    this.setGameState({ 
        nome_jogador_global: name.toUpperCase(),
        all_characters_in_game_pool: allChars
    });
    this.addLog(`> ${name.toUpperCase()}`, 'log-heroi');
    this.ativarPersonagensPorFase();
    this.gameData.orientacao_inicial_frases.forEach((frase: string) => this.addLog(frase, 'log-sistema'));
    this.addLog(`[GABRIEL]: ${saudacao}`, this.getNpcColor(this.gameData.personagens_base.gabriel));
  }

  ativarPersonagensPorFase() {
    const phaseKey = `fase_${this.gameState.fase_atual}`;
    const phaseData = this.gameData.fases_jogo[phaseKey];
    if (!phaseData) return;
    
    const personagensAtuais = {...this.gameState.personagens_atuais};

    phaseData.initial_active_npcs.forEach((npcName: string) => {
        if (!personagensAtuais[npcName]) {
            const baseNpcData = this.gameState.all_characters_in_game_pool[npcName];
            if (baseNpcData) {
                personagensAtuais[npcName] = JSON.parse(JSON.stringify(baseNpcData));
                this.addLog(`${npcName.toUpperCase()} apareceu online.`, 'log-sistema');
            }
        }
    });
    this.setGameState({ personagens_atuais: personagensAtuais });
  }

  getNpcColor(npcData: NpcData): string {
    if (npcData.tipo === "agente") return 'log-agente';
    if (npcData.tipo === "guia") return 'log-heroi';
    const fe = npcData.fe || 50;
    if (fe <= 20) return 'npc-low-faith';
    if (fe <= 80) return 'npc-mid-faith';
    return 'npc-high-faith';
  }

  processarInteracaoFe(npcState: NpcData, npcName: string, efeitoDialogo: number = 0): boolean {
    if (npcState.tipo === 'guia' || npcState.tipo === 'agente') return false;

    const feNpcAntes = npcState.fe;
    npcState.fe += efeitoDialogo;
    const diferenca = this.gameState.heroi_fe_percent - npcState.fe;
    const mudanca = diferenca / 2;
    
    const novaFeHeroi = Math.max(0, Math.min(100, this.gameState.heroi_fe_percent - mudanca));
    npcState.fe = Math.max(0, Math.min(100, npcState.fe + mudanca));

    this.setGameState({ heroi_fe_percent: novaFeHeroi });

    this.addLog(`[FÉ]: A sua Fé: ${this.gameState.heroi_fe_percent.toFixed(0)}% | Fé de ${npcName.toUpperCase()}: ${npcState.fe.toFixed(0)}%`, 'log-sistema');
    return npcState.fe > feNpcAntes;
  }
  
  recompensarJogador() {
    if (Math.random() < 0.25) {
        const itemKey = Object.keys(this.gameData.itens)[Math.floor(Math.random() * Object.keys(this.gameData.itens).length)];
        const heroiInventory = [...this.gameState.heroi_inventory, itemKey];
        this.setGameState({ heroi_inventory: heroiInventory });
        const itemNome = this.gameData.itens[itemKey].nome;
        this.addLog(`[SISTEMA]: A sua interação positiva gerou um '${itemNome}'!`, 'log-positivo');
    }
  }

  aplicarEfeitoItem(itemKey: string) {
    const item = this.gameData.itens[itemKey];
    if (!item || !item.efeito) return;

    const efeito = item.efeito;
    let itemConsumido = true;

    if (efeito.tipo === 'aumento_permanente_fe') {
      const novaFe = Math.min(100, this.gameState.heroi_fe_percent + efeito.valor);
      this.setGameState({ heroi_fe_percent: novaFe });
      this.addLog(`Você usou ${item.nome} e a sua fé base aumentou para ${novaFe.toFixed(0)}%.`, 'log-positivo');
    } 
    else if (efeito.tipo === 'aumento_temporario_fe') {
      const buff: Buff = { tipo: efeito.tipo, valor: efeito.valor, turnos_restantes: efeito.duracao };
      this.setGameState({ activeBuffs: [...this.gameState.activeBuffs, buff] });
      this.addLog(`Você sente a sua fé fortalecida pela ${item.nome}. O efeito durará ${efeito.duracao} turnos.`, 'log-positivo');
    }
    else if (efeito.tipo === 'protecao_agente') {
      const buff: Buff = { tipo: efeito.tipo, turnos_restantes: efeito.cargas };
      this.setGameState({ activeBuffs: [...this.gameState.activeBuffs, buff] });
      this.addLog(`O ${item.nome} protege a sua alma. Você tem ${efeito.cargas} carga(s) de proteção.`, 'log-positivo');
    } else {
      itemConsumido = false;
    }

    if (itemConsumido) {
      const inventory = [...this.gameState.heroi_inventory];
      const itemIndex = inventory.indexOf(itemKey);
      if (itemIndex > -1) {
        inventory.splice(itemIndex, 1);
        this.setGameState({ heroi_inventory: inventory });
      }
    }
  }

  decrementarBuffs() {
    if (this.gameState.activeBuffs.length === 0) return;

    const buffsAtivos = this.gameState.activeBuffs.map(buff => {
      buff.turnos_restantes--;
      return buff;
    }).filter(buff => buff.turnos_restantes > 0);

    if (this.gameState.activeBuffs.length > buffsAtivos.length) {
        this.addLog("O efeito de um item desvaneceu-se.", 'log-negativo');
    }

    this.setGameState({ activeBuffs: buffsAtivos });
  }
  
  addPista(pista: string) {
    const novasPistas = [...this.gameState.pistas, pista];
    this.setGameState({ pistas: novasPistas });
    this.addLog(`[SISTEMA]: Nova pista adquirida: '${pista}'`, 'log-positivo');
    this.checkPhaseCompletion();
  }

  checkPhaseCompletion() {
    const phaseKey = `fase_${this.gameState.fase_atual}`;
    const phaseData = this.gameData.fases_jogo[phaseKey];
    if (!phaseData || !phaseData.pistas_necessarias) return;

    if (this.gameState.pistas.length >= phaseData.pistas_necessarias) {
        const faseAnterior = this.gameState.fase_atual;
        if (faseAnterior >= Object.keys(this.gameData.fases_jogo).length) {
            return;
        }
        
        this.setGameState({ fase_atual: faseAnterior + 1 });
        this.addLog(`[SISTEMA]: Você completou a Fase ${faseAnterior}!`, 'log-positivo');
        this.ativarPersonagensPorFase();
    }
  }

  private autosaveToLocalStorage() {
    localStorage.setItem('redencao_autosave', JSON.stringify(this.gameState));
  }

  loadFromAutosave() {
    const saved = localStorage.getItem('redencao_autosave');
    if (saved) {
      this.setGameState(JSON.parse(saved));
      this.clearLog();
      this.addLog("Jogo continuado a partir do último ponto salvo.", 'log-positivo');
    } else {
      this.addLog("Nenhum jogo salvo encontrado para continuar. Comece um 'novo' jogo.", 'log-negativo');
    }
  }

  exportSaveToFile() {
    const dataStr = JSON.stringify(this.gameState, null, 2);
    const dataBlob = new Blob([dataStr], { type: "application/json" });
    const url = window.URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `redencao_save_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    window.URL.revokeObjectURL(url);
    this.addLog("Ficheiro de salvamento gerado. Verifique os seus downloads.", 'log-positivo');
  }

  requestFileUpload() {
    this.fileUploadRequest.next();
  }

  loadGameFromFile(file: File) {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result;
        if (typeof text === 'string') {
          const loadedState = JSON.parse(text);
          if (loadedState.hasOwnProperty('heroi_fe_percent')) {
            this.setGameState(loadedState);
            this.clearLog();
            this.addLog("Jogo carregado com sucesso a partir do ficheiro!", 'log-positivo');
          } else {
            throw new Error("Formato de ficheiro inválido.");
          }
        }
      } catch (error) {
        this.addLog("Erro: O ficheiro de salvamento parece estar corrompido ou tem um formato inválido.", 'log-negativo');
      }
    };
    reader.readAsText(file);
  }

  private getInitialGameState(): GameState {
    return JSON.parse(JSON.stringify(this.initialGameState));
  }
}
