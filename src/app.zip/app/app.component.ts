// src/app/app.component.ts

import { Component, OnInit, ViewChild, ElementRef, AfterViewChecked, HostListener, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Observable, Subscription } from 'rxjs';

import { GameStateService } from './core/services/game-state.service';
import { CommandService } from './core/services/command.service';
import { InactivityService } from './core/services/inactivity.service';
import { LogLine, GameState } from './core/models/game.interfaces';
import { ScreensaverComponent } from './screensaver/screensaver.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, ScreensaverComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  @ViewChild('commandInputElement') private commandInput!: ElementRef;
  @ViewChild('fileInput') private fileInput!: ElementRef;

  command: string = '';
  promptText: string = '>';
  commandHistory: string[] = [];
  historyIndex: number = 0;

  terminalLog$: Observable<LogLine[]>;
  gameState$: Observable<GameState>;
  isScreensaverActive$: Observable<boolean>;
  private fileUploadSub!: Subscription;

  constructor(
    private http: HttpClient,
    public gameStateSvc: GameStateService,
    private commandSvc: CommandService,
    private inactivitySvc: InactivityService
  ) {
    this.terminalLog$ = this.gameStateSvc.terminalLog$;
    this.gameState$ = this.gameStateSvc.gameState$;
    this.isScreensaverActive$ = this.inactivitySvc.isScreensaverActive$;
  }

  ngOnInit() {
    this.http.get<any>('assets/data.json').subscribe(data => {
      this.gameStateSvc.gameData = data;
      this.gameStateSvc.showInitialScreen();
      this.focusInput();
      this.inactivitySvc.resetInactivityTimer();
    });

    this.fileUploadSub = this.gameStateSvc.fileUploadRequest$.subscribe(() => {
      this.fileInput.nativeElement.click();
    });
  }

  ngOnDestroy() {
    if (this.fileUploadSub) {
      this.fileUploadSub.unsubscribe();
    }
    this.inactivitySvc.stopTimer();
  }
  
  @HostListener('window:mousemove')
  @HostListener('window:keydown')
  onUserActivity() {
    this.inactivitySvc.resetInactivityTimer();
  }

  focusInput() {
    if (this.commandInput && this.commandInput.nativeElement) {
      this.commandInput.nativeElement.focus();
    }
  }

  handleCommand() {
    const command = this.command.trim().toLowerCase();
    if (!command) return;

    this.commandHistory.push(this.command);
    this.historyIndex = this.commandHistory.length;

    const currentGameState = this.gameStateSvc.gameState;
    if (currentGameState.nome_jogador_global === 'PENDING') {
      this.gameStateSvc.setPlayerName(command);
    } else {
      this.commandSvc.processCommand(command);
    }
    
    this.command = '';
  }

  navigateHistory(direction: 'up' | 'down') {
    if (direction === 'up' && this.historyIndex > 0) {
      this.historyIndex--;
    } else if (direction === 'down' && this.historyIndex < this.commandHistory.length) {
      this.historyIndex++;
    } else if (direction === 'down') {
      this.historyIndex = this.commandHistory.length;
    }
    this.command = this.commandHistory[this.historyIndex] || '';
  }

  getObjetivoAtual(): string {
    const gameState = this.gameStateSvc.gameState;
    const gameData = this.gameStateSvc.gameData;
    if (!gameData.fases_jogo) return '';
    const phaseKey = `fase_${gameState.fase_atual}`;
    if (gameData.fases_jogo[phaseKey]) {
      const objetivoIndex = gameData.fases_jogo[phaseKey].objetivo_indice;
      return gameData.objetivos[objetivoIndex];
    }
    return "Redenção alcançada.";
  }

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.gameStateSvc.loadGameFromFile(input.files[0]);
    }
    input.value = '';
  }
}